# py-thin-plate-spline

Code for computing interpolating / approximating thin plate spline surfaces.
See [TPS.ipynb](TPS.ipynb) for code and illustrations.
